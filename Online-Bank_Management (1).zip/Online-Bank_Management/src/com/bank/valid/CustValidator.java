package com.bank.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.bank.dto.Customer;
@Service
public class CustValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Customer.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"custName","unKey","Username is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custPass","upKey", "Password is required");
		
	}

	
}