package com.bank.cntr;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bank.dto.Customer;
import com.bank.service.CustService;
import com.bank.valid.CustValidator;

@Controller
public class CustController {
	@Autowired
	private CustService custService;
	
	@Autowired
	private CustValidator custValidator;
	
	@RequestMapping(value="/pre_reg_form.htm" , method=RequestMethod.GET)
	public String preRegForm(ModelMap map) {
		map.put("cust", new Customer());
		return "Reg_form";
		
	}
	
	@RequestMapping(value="/reg.htm" , method=RequestMethod.POST)
	public String register(Customer cust,ModelMap map) {
		custService.addCust(cust);
		return "index";
		
	}
	
	@RequestMapping(value="/pre_log_form.htm" , method=RequestMethod.GET)
	public String preLogForm(ModelMap map) {
		map.put("cust", new Customer());
		return "login";
		
	}
	
	@RequestMapping(value="/login.htm" , method=RequestMethod.POST)
	public String login(Customer cust,BindingResult result,ModelMap map,HttpSession session) {
		
		custValidator.validate(cust,result);
		if(result.hasErrors()) {
			map.put("cust",cust);
			return "login";
		}
		
		System.out.println("Done!!");
		boolean b=custService.findCust(cust);
		
		if(b) {
			session.setAttribute("cust", cust);
			return "home";
		}else {
			return "login";
		}
		
	}
	
	
	@RequestMapping(value="/checkAmt.htm" , method=RequestMethod.GET)
	public String checkAmt(ModelMap map,HttpSession session) {
			int accNo=((Customer)session.getAttribute("cust")).getAccNo();
			Customer cust = custService.selectAll(accNo);
			map.put("amt",cust);
			
			
			return "check_Amt";
		
		
	}
	
	
	@RequestMapping(value="/deposite1.htm" , method=RequestMethod.GET)
	public String deposite1(ModelMap map) {
			
			map.put("cust",new Customer());
			
			
			return "deposite";
		
		
	}
	
	
	@RequestMapping(value="/deposite.htm" , method=RequestMethod.POST)
	public String deposite(HttpSession session,ModelMap map,Customer c) {
			
		
		int accNo=((Customer)session.getAttribute("cust")).getAccNo();
		Customer cust = custService.selectAll(accNo);
		double amount = cust.getAmt() + c.getAmt();
		cust.setAmt(amount);
		
		custService.deposite(cust);
			
		
			
			return "home";
		
		
	}
	
	
	@RequestMapping(value="/withdraw1.htm" , method=RequestMethod.GET)
	public String withdraw1(ModelMap map) {
			
			map.put("cust",new Customer());
			
			
			return "withdraw";
		
		
	}
	
	
	
	@RequestMapping(value="/withdraw.htm" , method=RequestMethod.POST)
	public String withdraw(HttpSession session,ModelMap map,Customer c) {
			
		
		int accNo=((Customer)session.getAttribute("cust")).getAccNo();
		Customer cust = custService.selectAll(accNo);
		
		if(c.getAmt()>cust.getAmt()) {
			map.put("msg","Your account balance is less than withdraw amount");
			map.put("cust",new Customer());
			return "withdraw";
		}
		else {
			double amount = cust.getAmt() - c.getAmt();
		
			cust.setAmt(amount);
		
			custService.deposite(cust);
			
			return "home";
		}
		
		
	}
	
	

}
